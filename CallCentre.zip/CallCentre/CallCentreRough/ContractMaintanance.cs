﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CallCentreRough
{
    public partial class ContractMaintanance : Form
    {
        public ContractMaintanance()
        {
            InitializeComponent();
        }

        //controls the labels
        int count = 0;

        private void ContractMaintanance_Load(object sender, EventArgs e)
        {
            comboBox1.Items.Add("");
            comboBox1.Items.Add("Bronze");
            comboBox1.Items.Add("Silver");
            comboBox1.Items.Add("Gold");
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            count++;

            if (true)
            {

            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem == "Gold")
            {
                //enable labels
                lblCoverage.Visible = true;
                lblPriority.Visible = true;
                lblPrice.Visible = true;

                //effect
                lblCoverage.Text = "24/7";
                lblPriority.Text = "1";
                lblPrice.Text = $"{count}";
            }else if (comboBox1.SelectedItem == "Silver")
            {
                //enable labels
                lblCoverage.Visible = true;
                lblPriority.Visible = true;
                lblPrice.Visible = true;

                //effect
                lblCoverage.Text = "24/7";
                lblPriority.Text = "2";
                lblPrice.Text = $"{count-200}";
            }
            else if (comboBox1.SelectedItem == "Bronze")
            {
                //enable labels
                lblCoverage.Visible = true;
                lblPriority.Visible = true;
                lblPrice.Visible = true;

                //effect
                lblCoverage.Text = "24/7";
                lblPriority.Text = "2";
                lblPrice.Text = $"{count - 400}";
            }
        }

        private void btnViewStud_Click(object sender, EventArgs e)
        {
            count = 800;
        }

        private void btnViewPartStud_Click(object sender, EventArgs e)
        {
            count = 2000;
        }
    }
}
