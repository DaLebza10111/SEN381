﻿
namespace CallCentreRough
{
    partial class ClientMaintanance
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.GbStudDet = new System.Windows.Forms.GroupBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.GbSearchStud = new System.Windows.Forms.GroupBox();
            this.btnSearchstudent = new System.Windows.Forms.Button();
            this.txtSudentNumberSearch = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.GbDisplayButtons = new System.Windows.Forms.GroupBox();
            this.btnViewFullStud = new System.Windows.Forms.Button();
            this.btnViewPartStud = new System.Windows.Forms.Button();
            this.btnViewStud = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.Gbnav = new System.Windows.Forms.GroupBox();
            this.btnLast = new System.Windows.Forms.Button();
            this.btnNext = new System.Windows.Forms.Button();
            this.btnPrevious = new System.Windows.Forms.Button();
            this.btnFirst = new System.Windows.Forms.Button();
            this.DgvDisplay = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.GbStudDet.SuspendLayout();
            this.GbSearchStud.SuspendLayout();
            this.GbDisplayButtons.SuspendLayout();
            this.Gbnav.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvDisplay)).BeginInit();
            this.SuspendLayout();
            // 
            // GbStudDet
            // 
            this.GbStudDet.Controls.Add(this.textBox7);
            this.GbStudDet.Controls.Add(this.textBox6);
            this.GbStudDet.Controls.Add(this.textBox5);
            this.GbStudDet.Controls.Add(this.textBox4);
            this.GbStudDet.Controls.Add(this.textBox3);
            this.GbStudDet.Controls.Add(this.textBox2);
            this.GbStudDet.Controls.Add(this.textBox1);
            this.GbStudDet.Controls.Add(this.label8);
            this.GbStudDet.Controls.Add(this.label9);
            this.GbStudDet.Controls.Add(this.label7);
            this.GbStudDet.Controls.Add(this.label6);
            this.GbStudDet.Controls.Add(this.label5);
            this.GbStudDet.Controls.Add(this.label4);
            this.GbStudDet.Controls.Add(this.label3);
            this.GbStudDet.Location = new System.Drawing.Point(12, 383);
            this.GbStudDet.Name = "GbStudDet";
            this.GbStudDet.Size = new System.Drawing.Size(220, 284);
            this.GbStudDet.TabIndex = 24;
            this.GbStudDet.TabStop = false;
            this.GbStudDet.Text = "Client Details";
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(95, 230);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(100, 20);
            this.textBox7.TabIndex = 18;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(95, 194);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(100, 20);
            this.textBox6.TabIndex = 17;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(95, 56);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(100, 20);
            this.textBox5.TabIndex = 16;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(95, 85);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(100, 20);
            this.textBox4.TabIndex = 15;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(95, 119);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 20);
            this.textBox3.TabIndex = 14;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(95, 160);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 13;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(95, 22);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 12;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(15, 160);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(38, 13);
            this.label8.TabIndex = 11;
            this.label8.Text = "Phone";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(14, 230);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(66, 13);
            this.label9.TabIndex = 10;
            this.label9.Text = "service level";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(15, 122);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(45, 13);
            this.label7.TabIndex = 4;
            this.label7.Text = "Address";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(14, 197);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(37, 13);
            this.label6.TabIndex = 3;
            this.label6.Text = "Status";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(15, 85);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 13);
            this.label5.TabIndex = 2;
            this.label5.Text = "Surname";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(15, 56);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(14, 29);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(43, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "clientID";
            // 
            // GbSearchStud
            // 
            this.GbSearchStud.Controls.Add(this.btnSearchstudent);
            this.GbSearchStud.Controls.Add(this.txtSudentNumberSearch);
            this.GbSearchStud.Controls.Add(this.label2);
            this.GbSearchStud.Location = new System.Drawing.Point(552, 253);
            this.GbSearchStud.Name = "GbSearchStud";
            this.GbSearchStud.Size = new System.Drawing.Size(181, 101);
            this.GbSearchStud.TabIndex = 27;
            this.GbSearchStud.TabStop = false;
            this.GbSearchStud.Text = "Search Client";
            // 
            // btnSearchstudent
            // 
            this.btnSearchstudent.Location = new System.Drawing.Point(9, 64);
            this.btnSearchstudent.Name = "btnSearchstudent";
            this.btnSearchstudent.Size = new System.Drawing.Size(130, 23);
            this.btnSearchstudent.TabIndex = 2;
            this.btnSearchstudent.Text = "Search client";
            this.btnSearchstudent.UseVisualStyleBackColor = true;
            // 
            // txtSudentNumberSearch
            // 
            this.txtSudentNumberSearch.Location = new System.Drawing.Point(9, 38);
            this.txtSudentNumberSearch.Name = "txtSudentNumberSearch";
            this.txtSudentNumberSearch.Size = new System.Drawing.Size(130, 20);
            this.txtSudentNumberSearch.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(6, 22);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Enter Client ID";
            // 
            // GbDisplayButtons
            // 
            this.GbDisplayButtons.Controls.Add(this.btnViewFullStud);
            this.GbDisplayButtons.Controls.Add(this.btnViewPartStud);
            this.GbDisplayButtons.Controls.Add(this.btnViewStud);
            this.GbDisplayButtons.Location = new System.Drawing.Point(552, 83);
            this.GbDisplayButtons.Name = "GbDisplayButtons";
            this.GbDisplayButtons.Size = new System.Drawing.Size(181, 157);
            this.GbDisplayButtons.TabIndex = 26;
            this.GbDisplayButtons.TabStop = false;
            this.GbDisplayButtons.Text = "Display buttons";
            // 
            // btnViewFullStud
            // 
            this.btnViewFullStud.Location = new System.Drawing.Point(12, 102);
            this.btnViewFullStud.Name = "btnViewFullStud";
            this.btnViewFullStud.Size = new System.Drawing.Size(163, 33);
            this.btnViewFullStud.TabIndex = 2;
            this.btnViewFullStud.Text = "View Business Clients";
            this.btnViewFullStud.UseVisualStyleBackColor = true;
            // 
            // btnViewPartStud
            // 
            this.btnViewPartStud.Location = new System.Drawing.Point(12, 63);
            this.btnViewPartStud.Name = "btnViewPartStud";
            this.btnViewPartStud.Size = new System.Drawing.Size(163, 33);
            this.btnViewPartStud.TabIndex = 1;
            this.btnViewPartStud.Text = "View Individual Clients";
            this.btnViewPartStud.UseVisualStyleBackColor = true;
            // 
            // btnViewStud
            // 
            this.btnViewStud.Location = new System.Drawing.Point(12, 24);
            this.btnViewStud.Name = "btnViewStud";
            this.btnViewStud.Size = new System.Drawing.Size(163, 33);
            this.btnViewStud.TabIndex = 0;
            this.btnViewStud.Text = "View All Clients";
            this.btnViewStud.UseVisualStyleBackColor = true;
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(552, 39);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(181, 38);
            this.btnExit.TabIndex = 25;
            this.btnExit.Text = "EXIT";
            this.btnExit.UseVisualStyleBackColor = true;
            // 
            // Gbnav
            // 
            this.Gbnav.Controls.Add(this.btnLast);
            this.Gbnav.Controls.Add(this.btnNext);
            this.Gbnav.Controls.Add(this.btnPrevious);
            this.Gbnav.Controls.Add(this.btnFirst);
            this.Gbnav.Location = new System.Drawing.Point(12, 317);
            this.Gbnav.Name = "Gbnav";
            this.Gbnav.Size = new System.Drawing.Size(534, 47);
            this.Gbnav.TabIndex = 23;
            this.Gbnav.TabStop = false;
            this.Gbnav.Text = "Navigation";
            // 
            // btnLast
            // 
            this.btnLast.Location = new System.Drawing.Point(428, 18);
            this.btnLast.Name = "btnLast";
            this.btnLast.Size = new System.Drawing.Size(75, 23);
            this.btnLast.TabIndex = 3;
            this.btnLast.Text = ">|";
            this.btnLast.UseVisualStyleBackColor = true;
            // 
            // btnNext
            // 
            this.btnNext.Location = new System.Drawing.Point(157, 18);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(75, 23);
            this.btnNext.TabIndex = 2;
            this.btnNext.Text = ">>";
            this.btnNext.UseVisualStyleBackColor = true;
            // 
            // btnPrevious
            // 
            this.btnPrevious.Location = new System.Drawing.Point(304, 19);
            this.btnPrevious.Name = "btnPrevious";
            this.btnPrevious.Size = new System.Drawing.Size(75, 23);
            this.btnPrevious.TabIndex = 1;
            this.btnPrevious.Text = "<<";
            this.btnPrevious.UseVisualStyleBackColor = true;
            // 
            // btnFirst
            // 
            this.btnFirst.Location = new System.Drawing.Point(15, 18);
            this.btnFirst.Name = "btnFirst";
            this.btnFirst.Size = new System.Drawing.Size(75, 23);
            this.btnFirst.TabIndex = 0;
            this.btnFirst.Text = "|<";
            this.btnFirst.UseVisualStyleBackColor = true;
            // 
            // DgvDisplay
            // 
            this.DgvDisplay.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvDisplay.Location = new System.Drawing.Point(12, 54);
            this.DgvDisplay.Name = "DgvDisplay";
            this.DgvDisplay.Size = new System.Drawing.Size(534, 256);
            this.DgvDisplay.TabIndex = 22;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(8, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(149, 24);
            this.label1.TabIndex = 21;
            this.label1.Text = "Client Maintance";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(254, 448);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(163, 33);
            this.button1.TabIndex = 3;
            this.button1.Text = "Add Client";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(254, 392);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(163, 33);
            this.button2.TabIndex = 28;
            this.button2.Text = "Update Client";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // ClientMaintanance
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(737, 683);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.GbStudDet);
            this.Controls.Add(this.GbSearchStud);
            this.Controls.Add(this.GbDisplayButtons);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.Gbnav);
            this.Controls.Add(this.DgvDisplay);
            this.Controls.Add(this.label1);
            this.Name = "ClientMaintanance";
            this.Text = "ClientMaintanance";
            this.GbStudDet.ResumeLayout(false);
            this.GbStudDet.PerformLayout();
            this.GbSearchStud.ResumeLayout(false);
            this.GbSearchStud.PerformLayout();
            this.GbDisplayButtons.ResumeLayout(false);
            this.Gbnav.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvDisplay)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox GbStudDet;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox GbSearchStud;
        private System.Windows.Forms.Button btnSearchstudent;
        private System.Windows.Forms.TextBox txtSudentNumberSearch;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox GbDisplayButtons;
        private System.Windows.Forms.Button btnViewFullStud;
        private System.Windows.Forms.Button btnViewPartStud;
        private System.Windows.Forms.Button btnViewStud;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.GroupBox Gbnav;
        private System.Windows.Forms.Button btnLast;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Button btnPrevious;
        private System.Windows.Forms.Button btnFirst;
        private System.Windows.Forms.DataGridView DgvDisplay;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
    }
}